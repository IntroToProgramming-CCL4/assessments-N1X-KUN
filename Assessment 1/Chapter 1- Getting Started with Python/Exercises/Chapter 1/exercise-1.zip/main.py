# Write a Python program to print the following string in a specific format.

print ("Twinkle, twinkle, little star,",
    "\n \t  How I wonder what you are!"+
        "\n \t Up above the world so high,",
        "\n \t Like a diamond in the sky.",
"\nTwinkle, twinkle, little star,"+
    "\n \t How I wonder what you are!") 

# The newline character has helped me to utilize the escape sequences of "\n" and "\t" to display it accurately