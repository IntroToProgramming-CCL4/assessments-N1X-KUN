#Write a Python program to get the Python version you are using.

import sys
print ("Python Version")
print (sys.version)
print ("Version infor.")
print (sys.version_info)

