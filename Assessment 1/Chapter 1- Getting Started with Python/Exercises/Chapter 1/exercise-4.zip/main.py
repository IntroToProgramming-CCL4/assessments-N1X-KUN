# Write three strings in different variables and print the output as one string.      

School = "MetaverseAge"
Subject = "Creative Computing"
Name = "Gerard" 

#string = Name + " is studying " + Subject + " in " + School
string = f"{Name} is studying {Subject} in {School}"
print (string)

